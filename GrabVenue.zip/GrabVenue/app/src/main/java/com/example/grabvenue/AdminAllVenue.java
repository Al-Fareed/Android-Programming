package com.example.grabvenue;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class AdminAllVenue extends AppCompatActivity {
    ListView listView;
    Database db = new Database(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_all_venue);

        ActionBar actionBar;
        actionBar = getSupportActionBar();
        actionBar.setTitle("All Venues");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#736767"));

        actionBar.setBackgroundDrawable(colorDrawable);

        listView = findViewById(R.id.venueListAdmin);
        showRecords();

    }
    public void showRecords() {
        ArrayList<VenueModel> venueList = db.read_venue();

        ListVenueAdapterAdmin venueListAdapterAdmin = new ListVenueAdapterAdmin(getApplicationContext(), venueList);
        listView.setAdapter(venueListAdapterAdmin);
    }
}