package com.example.grabvenue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private static final String dbname = "grabvenue3.db";

    public Database(@Nullable Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String q = "create table venue (vid INTEGER primary key, vtype text, capacity text, title text, address text, facilities text, vimage blob)";

        String b = "create table booking (bid INTEGER primary key, bdate text, btime text, vid INTEGER)";
        sqLiteDatabase.execSQL(q);
        sqLiteDatabase.execSQL(b);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists venue");
        onCreate(sqLiteDatabase);
    }

    public boolean insert_data(String vtype, String capacity, String title, String address, String facilities, byte[] vimage){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues c = new ContentValues();
        c.put("vtype", vtype);
        c.put("capacity", capacity);
        c.put("title", title);
        c.put("address", address);
        c.put("facilities", facilities);
        c.put("vimage", vimage);

        long r = db.insert("venue",null, c);
        if(r == -1)
            return false;
        else
            return true;
    }

    public boolean insertBooking(String date, String time, int vid){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues c = new ContentValues();
        c.put("bdate", date);
        c.put("btime", time);
        c.put("vid", vid);

        long r = db.insert("booking",null, c);
        if(r == -1)
            return false;
        else
            return true;
    }

    public void deleteBooking(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("venue", "vid"+ " = ?", new String[] {String.valueOf(id)});

        db.close();
    }

    public ArrayList<VenueModel> read_venue(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM venue", null);

        ArrayList<VenueModel> arrVenue = new ArrayList<>();

        while(cursor.moveToNext()){
            VenueModel model = new VenueModel();
            model.vid = String.valueOf(cursor.getInt(0));
            model.vtype = cursor.getString(1);
            model.capacity = cursor.getString(2);
            model.title = cursor.getString(3);
            model.address = cursor.getString(4);
            model.facilities = cursor.getString(5);
            model.vimage = cursor.getBlob(6);
            arrVenue.add(model);
        }
        return arrVenue;
    }

    public ArrayList<VenueModel> getAllBooking(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM booking, venue where booking.vid = venue.vid", null);

        ArrayList<VenueModel> arrVenue = new ArrayList<>();

        while(cursor.moveToNext()){
            VenueModel model = new VenueModel();
            model.vid = String.valueOf(cursor.getInt(0) + cursor.getInt(3));
            model.capacity = cursor.getString(6);
            model.vtype = cursor.getString(5);
            model.title = cursor.getString(7);
            model.address = cursor.getString(8);
            model.facilities = cursor.getString(9);
            model.vimage = cursor.getBlob(10);
            model.setDate(cursor.getString(1) + "-" +cursor.getString(2));
            arrVenue.add(model);
        }
        return arrVenue;
    }

}
