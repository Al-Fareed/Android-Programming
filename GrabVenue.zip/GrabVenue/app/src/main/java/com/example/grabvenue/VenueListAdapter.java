package com.example.grabvenue;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class VenueListAdapter extends BaseAdapter {

    Context context;
    private ArrayList<VenueModel> listData;
    LayoutInflater inflater;

    Button mDialogButton;
    TextView okay_text, cancel_text;
    TextView title,address;
    ImageView imageView;
    Database db;

    public VenueListAdapter(Context ctx, ArrayList<VenueModel> listData){
        this.context = ctx;
        this.listData = listData;
        inflater = LayoutInflater.from(ctx);
        db = new Database(inflater.getContext());
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder {
        TextView txtView;
        TextView address;
        EditText dateText;
        EditText timeText;
        ImageView venueLogo;
        Button bookBtn;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view == null) {
            view = inflater.inflate(R.layout.activity_venueitemlist, null);
            holder = new ViewHolder();
            holder.txtView = view.findViewById(R.id.venueTitle);
            holder.address = view.findViewById(R.id.address);

            holder.dateText = view.findViewById(R.id.editTextDate);
            holder.timeText = view.findViewById(R.id.editTextTime);
            holder.venueLogo  = view.findViewById(R.id.venueLogo);

            holder.bookBtn = view.findViewById(R.id.bookBtn);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.txtView.setText(listData.get(i).getTitle());
        holder.address.setText(listData.get(i).getAddress());
        holder.venueLogo.setImageBitmap(getImage(listData.get(i).getVimage()));



        holder.bookBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                db.insertBooking(
                        holder.dateText.getText().toString(),
                        holder.timeText.getText().toString(),
                        Integer.parseInt(listData.get(i).getId())
                );
//                ((UserAllVenue) inflater.getContext()).showNotification(
//                        "Venue Booked",
//                        listData.get(i).getTitle() + " Booked on " + holder.dateText.getText().toString()  + " @ " + holder.timeText.getText().toString()
//                );
                Toast.makeText(context, "Booked Successfully", Toast.LENGTH_SHORT).show();
                holder.dateText.setText("");
                holder.timeText.setText("");
            }
        });

        return view;
    }
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }
}
