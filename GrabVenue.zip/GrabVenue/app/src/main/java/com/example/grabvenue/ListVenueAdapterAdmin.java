package com.example.grabvenue;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ListVenueAdapterAdmin extends BaseAdapter {

    Context context;
    private ArrayList<VenueModel> listData;
    LayoutInflater inflater;

    Database db;

    public ListVenueAdapterAdmin(Context ctx, ArrayList<VenueModel> listData){
        this.context = ctx;
        this.listData = listData;
        inflater = LayoutInflater.from(ctx);
        db = new Database(inflater.getContext());
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder {
        TextView txtView,address;
        ImageView image;
        Button btn;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view == null) {
            view = inflater.inflate(R.layout.layout_venue_admin, null);
            holder = new ViewHolder();

            holder.txtView = view.findViewById(R.id.titleView);
            holder.address = view.findViewById(R.id.addressView);
            holder.image = view.findViewById(R.id.imageView6);
            holder.btn = view.findViewById(R.id.deleteBtn);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.txtView.setText(listData.get(i).getTitle());
        holder.address.setText(listData.get(i).getAddress());
        holder.image.setImageBitmap(getImage(listData.get(i).getVimage()));

        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteBooking(Integer.parseInt(listData.get(i).getId()));
//                ((AdminAllVenue) context).showRecords();
            }
        });
        return view;
    }
    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }
}
