package com.example.grabvenue;

public class VenueModel {
    String vid;
    String vtype;
    String capacity;
    String title;
    String address;
    String facilities;
    byte[] vimage;
    String date;

    public VenueModel() {}

    public VenueModel(String id,String type,String capacity, String title, String address, String facilities, byte[] vimage) {
        this.vid = id;
        this.vtype = type;
        this.capacity = capacity;
        this.title = title;
        this.address = address;
        this.facilities = facilities;
        this.vimage = vimage;
    }

    public VenueModel(String type,String capacity, String title, String address, String facilities, byte[] vimage) {
        this.vtype = type;
        this.capacity = capacity;
        this.title = title;
        this.address = address;
        this.facilities = facilities;
        this.vimage = vimage;
    }

    public String getId() {return vid;}
    public void setId(String id) {this.vid = id;}

    public String getType() {return vtype;}
    public void setType(String type) {this.vtype = type;}

    public String getCapacity() {return capacity;}
    public void setCapacity(String capacity) {this.capacity = capacity;}

    public String getTitle() {return title;}
    public void setTitle(String title) {this.title = title;}

    public String getAddress() {return address;}
    public void setAddress(String address) {this.address = address;}

    public String getFacilities() {return facilities;}
    public void setFacilities(String facilities) {this.facilities = facilities;}


    public String getDate() {return date;}
    public void setDate(String date) {this.date = date;}


    public byte[] getVimage() {return vimage;}
    public void setVimage(byte[] vimage) {this.vimage = vimage;}
}
