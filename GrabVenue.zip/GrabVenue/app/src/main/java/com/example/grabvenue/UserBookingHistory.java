package com.example.grabvenue;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class UserBookingHistory extends AppCompatActivity {

    ListView listView;
    Database db = new Database(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_booking_history);


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        actionBar.setTitle("Booking History");

        listView = findViewById(R.id.bookList);

        ArrayList<VenueModel> bookingList = db.getAllBooking();


        ListHistoryAdapter historyAdapter = new ListHistoryAdapter(getApplicationContext(), bookingList);
        listView.setAdapter(historyAdapter);
    }
}